<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'comment_order' => 'desc',
  'is_approve' => 'off',
  'per_page_num' => '20',
  'home_page_num' => '20',
  'timespan' => '10',
  'words_limit' => '8000',
);
