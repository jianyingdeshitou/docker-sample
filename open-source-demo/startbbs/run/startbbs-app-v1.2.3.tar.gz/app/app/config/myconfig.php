<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'site_name' => 'StartBBS- 开源微社区-烧饼bbs',
  'index_page' => 'index.php',
  'show_captcha' => 'on',
  'site_close' => 'on',
  'site_close_msg' => '网站升级中，暂时关闭。',
  'basic_folder' => '',
  'version' => false,
  'static' => 'white',
  'themes' => 'default',
  'logo' => 'Start<span class=\'green\'>BBS</span>',
  'auto_tag' => 'on',
  'encryption_key' => '3a5a39e215fc2c9d83ec4f7c2ccb38a8',
);
